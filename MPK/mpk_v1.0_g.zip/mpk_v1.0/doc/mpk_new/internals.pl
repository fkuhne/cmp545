# LaTeX2HTML 2002 (1.62)
# Associate internals original text with physical files.


$key = q/sec:robots/;
$ref_files{$key} = "$dir".q|node3.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:rob_file/;
$ref_files{$key} = "$dir".q|node4.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:scenes/;
$ref_files{$key} = "$dir".q|node2.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:rob_hardcoded/;
$ref_files{$key} = "$dir".q|node5.html|; 
$noresave{$key} = "$nosave";

1;

