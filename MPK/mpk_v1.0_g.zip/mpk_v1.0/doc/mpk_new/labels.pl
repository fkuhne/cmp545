# LaTeX2HTML 2002 (1.62)
# Associate labels original text with physical files.


$key = q/sec:robots/;
$external_labels{$key} = "$URL/" . q|node3.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:rob_file/;
$external_labels{$key} = "$URL/" . q|node4.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:scenes/;
$external_labels{$key} = "$URL/" . q|node2.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:rob_hardcoded/;
$external_labels{$key} = "$URL/" . q|node5.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 2002 (1.62)
# labels from external_latex_labels array.


1;

