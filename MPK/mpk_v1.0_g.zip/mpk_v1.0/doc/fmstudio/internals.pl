# LaTeX2HTML 2002 (1.62)
# Associate internals original text with physical files.


$key = q/sec:database_commands/;
$ref_files{$key} = "$dir".q|node6.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:example_session/;
$ref_files{$key} = "$dir".q|node2.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:commands/;
$ref_files{$key} = "$dir".q|node4.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:command_line_options/;
$ref_files{$key} = "$dir".q|node3.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:intro/;
$ref_files{$key} = "$dir".q|node1.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:general_commands/;
$ref_files{$key} = "$dir".q|node5.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:mouse/;
$ref_files{$key} = "$dir".q|node7.html|; 
$noresave{$key} = "$nosave";

1;

