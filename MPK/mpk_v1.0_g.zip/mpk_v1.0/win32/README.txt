README for this folder:

This folder has 2 sub-folders:

-fmstudio_.NET_2002: It has the Visual Studio 
.NET 2002 project for the MPK software. 

-fmstudio_VS_6.0: It has the Visual Studio 6.0 
project for the MPK software.