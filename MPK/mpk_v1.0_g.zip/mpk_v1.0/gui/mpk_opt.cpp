double mpk_optimize(double p[], int n, 
		    double (*func)(double []),
		    void (*dfunc)(double [], double []))
{
  return 0;
}

